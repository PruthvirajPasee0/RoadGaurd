import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import * as authService from '../services/mockAuth';
import { toast } from 'react-toastify';

const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    if (authService.isAuthenticated()) {
      const currentUser = authService.getCurrentUser();
      setUser(currentUser);
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      const result = await authService.loginWithEmail(email, password);
      if (result.success) {
        setUser(result.user);
        toast.success('Login successful!');
        
        // Redirect based on role
        switch (result.user.role) {
          case 'admin':
            navigate('/admin/dashboard');
            break;
          case 'worker':
            navigate('/worker/dashboard');
            break;
          default:
            navigate('/dashboard');
        }
        return { success: true };
      } else {
        toast.error(result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      toast.error('Login failed. Please try again.');
      return { success: false, error: error.message };
    }
  };

  const loginWithOTP = async (phone, otp) => {
    try {
      const result = await authService.verifyOTP(phone, otp);
      if (result.success) {
        setUser(result.user);
        toast.success('Login successful!');
        
        // Redirect based on role
        switch (result.user.role) {
          case 'admin':
            navigate('/admin/dashboard');
            break;
          case 'worker':
            navigate('/worker/dashboard');
            break;
          default:
            navigate('/dashboard');
        }
        return { success: true };
      } else {
        toast.error(result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      toast.error('OTP verification failed.');
      return { success: false, error: error.message };
    }
  };

  const signup = async (userData) => {
    try {
      const result = await authService.register(userData);
      if (result.success) {
        setUser(result.user);
        toast.success('Registration successful!');
        navigate('/dashboard');
        return { success: true };
      } else {
        toast.error(result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      toast.error('Registration failed. Please try again.');
      return { success: false, error: error.message };
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
    toast.info('Logged out successfully');
    navigate('/login');
  };

  const value = {
    user,
    loading,
    login,
    loginWithOTP,
    signup,
    logout,
    isAuthenticated: !!user,
    userRole: user?.role
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
