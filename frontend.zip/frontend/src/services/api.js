import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api',
});

export const fetchWorkshopsByDistance = async ({ lat, lng, radiusKm, service }) => {
  const params = { lat, lng, radiusKm, service };
  const { data } = await api.get('/workshops', { params });
  return data.data;
};

export default api;
