import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { sendOTP } from '../services/mockAuth';
import { FiMail, FiLock, FiPhone, FiKey } from 'react-icons/fi';
import '../styles/Login.css';

const Login = () => {
  const [loginMethod, setLoginMethod] = useState('email'); // 'email' or 'otp'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const { login, loginWithOTP } = useAuth();

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    const result = await login(email, password);
    if (!result.success) {
      setError(result.error);
    }
    setLoading(false);
  };

  const handleSendOTP = async () => {
    if (!phone) {
      setError('Please enter phone number');
      return;
    }
    
    setError('');
    setLoading(true);
    
    const result = await sendOTP(phone);
    if (result.success) {
      setOtpSent(true);
      setError(''); // Clear any previous errors
      // Show the mock OTP to user for demo
      alert('Demo OTP: 123456');
    } else {
      setError(result.error);
    }
    setLoading(false);
  };

  const handleOTPLogin = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    
    const result = await loginWithOTP(phone, otp);
    if (!result.success) {
      setError(result.error);
    }
    setLoading(false);
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1>Welcome Back</h1>
          <p>Sign in to access roadside assistance</p>
        </div>

        <div className="login-method-tabs">
          <button
            className={`tab-btn ${loginMethod === 'email' ? 'active' : ''}`}
            onClick={() => {
              setLoginMethod('email');
              setError('');
              setOtpSent(false);
            }}
          >
            <FiMail /> Email Login
          </button>
          <button
            className={`tab-btn ${loginMethod === 'otp' ? 'active' : ''}`}
            onClick={() => {
              setLoginMethod('otp');
              setError('');
            }}
          >
            <FiPhone /> OTP Login
          </button>
        </div>

        {loginMethod === 'email' ? (
          <form onSubmit={handleEmailLogin} className="login-form">
            <div className="form-group">
              <label htmlFor="email" className="label">
                <FiMail /> Email Address
              </label>
              <input
                type="email"
                id="email"
                className="input"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="password" className="label">
                <FiLock /> Password
              </label>
              <input
                type="password"
                id="password"
                className="input"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && <div className="error-text">{error}</div>}

            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <span className="spinner"></span> : 'Sign In'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleOTPLogin} className="login-form">
            <div className="form-group">
              <label htmlFor="phone" className="label">
                <FiPhone /> Phone Number
              </label>
              <div className="phone-input-group">
                <input
                  type="tel"
                  id="phone"
                  className="input"
                  placeholder="+91 98765 43210"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  disabled={otpSent}
                  required
                />
                {!otpSent && (
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handleSendOTP}
                    disabled={loading}
                  >
                    Send OTP
                  </button>
                )}
              </div>
            </div>

            {otpSent && (
              <div className="form-group">
                <label htmlFor="otp" className="label">
                  <FiKey /> Enter OTP
                </label>
                <input
                  type="text"
                  id="otp"
                  className="input"
                  placeholder="Enter 6-digit OTP"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  maxLength="6"
                  required
                />
                <button
                  type="button"
                  className="resend-btn"
                  onClick={handleSendOTP}
                  disabled={loading}
                >
                  Resend OTP
                </button>
              </div>
            )}

            {error && <div className="error-text">{error}</div>}

            {otpSent && (
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? <span className="spinner"></span> : 'Verify & Login'}
              </button>
            )}
          </form>
        )}

        <div className="demo-credentials">
          <h3>Demo Credentials:</h3>
          <div className="credential-list">
            <div className="credential-item">
              <strong>User:</strong> user@demo.com / user123 / +919876543210
            </div>
            <div className="credential-item">
              <strong>Admin:</strong> admin@demo.com / admin123 / +919876543211
            </div>
            <div className="credential-item">
              <strong>Worker:</strong> worker@demo.com / worker123 / +919876543212
            </div>
            <div className="credential-item">
              <strong>OTP for all:</strong> 123456
            </div>
          </div>
        </div>

        <div className="login-footer">
          <p>
            Don't have an account? <Link to="/signup">Sign Up</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
