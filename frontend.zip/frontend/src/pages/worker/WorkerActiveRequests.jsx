import React, { useMemo } from 'react';
import { mockServiceRequests } from '../../services/mockData';
import { Link } from 'react-router-dom';

const WorkerActiveRequests = () => {
  const active = useMemo(() => mockServiceRequests.filter(r => r.status !== 'completed'), []);

  return (
    <div className="container fade-in">
      <div className="card" style={{ marginBottom: '1rem' }}>
        <h2>Active Requests</h2>
        <p style={{ color: 'var(--text-secondary)' }}>View and manage current assignments</p>
      </div>

      {active.length === 0 ? (
        <div className="card" style={{ textAlign: 'center' }}>
          <p>No active requests</p>
        </div>
      ) : (
        <div className="grid grid-cols-2">
          {active.map(req => (
            <div key={req.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <h3>{req.service}</h3>
                <span style={{ textTransform: 'capitalize', color: 'var(--text-secondary)' }}>{req.status}</span>
              </div>
              <div style={{ color: 'var(--text-secondary)', marginBottom: 8 }}>{req.location?.address}</div>
              <div style={{ display: 'flex', gap: 12, marginBottom: 12, color: 'var(--text-secondary)', fontSize: 14 }}>
                <span>Vehicle: {req.vehicleInfo?.make} {req.vehicleInfo?.model}</span>
                <span>Reg: {req.vehicleInfo?.registrationNumber}</span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Link to={`/requests/${req.id}`} className="btn">Open</Link>
                <button className="btn btn-secondary" disabled>Mark Complete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WorkerActiveRequests;
