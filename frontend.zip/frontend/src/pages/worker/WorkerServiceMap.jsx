import React, { useEffect, useMemo, useState } from 'react';
import { mockServiceRequests, simulateMechanicMovement } from '../../services/mockData';

const WorkerServiceMap = () => {
  const active = useMemo(() => mockServiceRequests.filter(r => r.status !== 'completed'), []);
  const [selectedId, setSelectedId] = useState(active[0]?.id || null);
  const selected = useMemo(() => active.find(r => r.id === selectedId), [active, selectedId]);
  const [mechanicLoc, setMechanicLoc] = useState(selected?.mechanicLocation || null);

  useEffect(() => {
    setMechanicLoc(selected?.mechanicLocation || null);
  }, [selectedId]);

  useEffect(() => {
    if (!selected || !mechanicLoc) return;
    const interval = setInterval(() => {
      setMechanicLoc(prev => {
        if (!prev) return prev;
        const next = simulateMechanicMovement(prev, selected.location);
        const closeEnough = Math.abs(next.lat - selected.location.lat) < 0.0005 && Math.abs(next.lng - selected.location.lng) < 0.0005;
        return closeEnough ? selected.location : next;
      });
    }, 1200);
    return () => clearInterval(interval);
  }, [selected?.id, selected?.location?.lat, selected?.location?.lng, mechanicLoc?.lat, mechanicLoc?.lng]);

  return (
    <div className="container fade-in" style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: '1rem' }}>
      <div className="card" style={{ height: '70vh', overflowY: 'auto' }}>
        <h3 style={{ marginBottom: 12 }}>Requests</h3>
        {active.map(req => (
          <button
            key={req.id}
            className="btn btn-secondary"
            style={{ display: 'block', width: '100%', textAlign: 'left', marginBottom: 8, background: selectedId === req.id ? 'var(--bg-hover)' : undefined }}
            onClick={() => setSelectedId(req.id)}
          >
            <div style={{ fontWeight: 600 }}>{req.service} • {req.id}</div>
            <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{req.location?.address}</div>
          </button>
        ))}
      </div>

      <div className="card" style={{ height: '70vh' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
          <div>
            <h3>Service Map</h3>
            <div style={{ color: 'var(--text-secondary)' }}>Live mechanic position (simulated)</div>
          </div>
          {selected && (
            <div style={{ textAlign: 'right', color: 'var(--text-secondary)' }}>
              <div><strong>Service:</strong> {selected.service}</div>
              <div><strong>Vehicle:</strong> {selected.vehicleInfo?.make} {selected.vehicleInfo?.model}</div>
            </div>
          )}
        </div>

        <div style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #111827 100%)',
          border: '1px solid var(--border-primary)',
          borderRadius: '0.75rem',
          position: 'relative',
          height: 'calc(100% - 80px)'
        }}>
          {!selected ? (
            <div style={{ display: 'grid', placeItems: 'center', height: '100%', color: 'var(--text-secondary)' }}>
              Select a request to view on map
            </div>
          ) : (
            <div style={{ padding: 16, height: '100%' }}>
              <div style={{ marginBottom: 12, display: 'flex', gap: 16, flexWrap: 'wrap', color: 'var(--text-secondary)' }}>
                <div>
                  <div style={{ fontSize: 12 }}>Mechanic</div>
                  <div style={{ fontFamily: 'monospace' }}>{mechanicLoc ? `${mechanicLoc.lat.toFixed(5)}, ${mechanicLoc.lng.toFixed(5)}` : '-'}</div>
                </div>
                <div>
                  <div style={{ fontSize: 12 }}>Destination</div>
                  <div style={{ fontFamily: 'monospace' }}>{`${selected.location.lat.toFixed(5)}, ${selected.location.lng.toFixed(5)}`}</div>
                </div>
              </div>

              <div style={{
                height: '100%',
                borderRadius: '0.5rem',
                border: '1px dashed var(--border-secondary)',
                display: 'grid',
                placeItems: 'center',
                color: 'var(--text-secondary)'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: 18, marginBottom: 8 }}>Map Placeholder</div>
                  <div style={{ fontSize: 12 }}>Integrate Google Maps here using the API key in .env</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WorkerServiceMap;
