import React, { useMemo } from 'react';
import { mockServiceRequests } from '../../services/mockData';
import { Link } from 'react-router-dom';

const WorkerCompleted = () => {
  const completed = useMemo(() => mockServiceRequests.filter(r => r.status === 'completed'), []);

  return (
    <div className="container fade-in">
      <div className="card" style={{ marginBottom: '1rem' }}>
        <h2>Completed Services</h2>
        <p style={{ color: 'var(--text-secondary)' }}>History of completed requests</p>
      </div>

      {completed.length === 0 ? (
        <div className="card" style={{ textAlign: 'center' }}>
          <p>No completed services yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-2">
          {completed.map(req => (
            <div key={req.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <h3>{req.service}</h3>
                <span style={{ color: 'var(--text-secondary)' }}>{new Date(req.completedAt).toLocaleString()}</span>
              </div>
              <div style={{ color: 'var(--text-secondary)', marginBottom: 8 }}>{req.location?.address}</div>
              <div style={{ display: 'flex', gap: 12, marginBottom: 8, color: 'var(--text-secondary)', fontSize: 14 }}>
                <span>Vehicle: {req.vehicleInfo?.make} {req.vehicleInfo?.model}</span>
                <span>Reg: {req.vehicleInfo?.registrationNumber}</span>
              </div>
              <div style={{ display: 'flex', gap: 12, marginBottom: 12, color: 'var(--text-secondary)', fontSize: 14 }}>
                <span>Rating: {req.rating ? `⭐ ${req.rating}` : 'N/A'}</span>
                <span>Amount: {req.totalCost ? `₹${req.totalCost.toLocaleString()}` : '-'}</span>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <Link to={`/requests/${req.id}`} className="btn">View Details</Link>
                <button className="btn btn-secondary" disabled>Invoice</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default WorkerCompleted;
